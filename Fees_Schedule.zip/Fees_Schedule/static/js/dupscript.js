document.getElementById('prev-day').addEventListener('click', function() {
    changeDate(-1);
  });
  
  document.getElementById('next-day').addEventListener('click', function() {
    changeDate(1);
  });
  
  document.getElementById('today-button').addEventListener('click', function() {
    window.location.reload();  // Refresh to today
  });
  
  function changeDate(offset) {
    let currentDate = document.getElementById('current-date').textContent;
    let currentDateObj = new Date(currentDate);
    currentDateObj.setDate(currentDateObj.getDate() + offset);
  
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const newDate = currentDateObj.toLocaleDateString('en-US', options);
    document.getElementById('current-date').textContent = newDate;
  
  }
  
  function updateSlotDisplay(data) {
    // Function to dynamically update slots based on new date
    let slotsContainer = document.getElementById('slots-container');
    slotsContainer.innerHTML = '';  // Clear existing slots
  
    data.slots.forEach(slot => {
      let slotDiv = document.createElement('div');
      slotDiv.classList.add('slot');
      slotDiv.innerHTML = `<span>${slot.time}</span> ${slot.booked ? '<span class="status booked">Booked</span>' : '<a href="/book/${slot.time}" class="book-btn">Book</a>'}`;
      slotsContainer.appendChild(slotDiv);
    });
  }
  