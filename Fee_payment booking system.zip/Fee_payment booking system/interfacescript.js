const prevDayBtn = document.getElementById('prev-day');
const nextDayBtn = document.getElementById('next-day');
const todayBtn = document.getElementById('today-button');
const currentDateSpan = document.getElementById('current-date');
const dateDisplayEl = document.getElementById('date-display').querySelector('h2');
const availableCountEl = document.getElementById('available-count');
const totalCountEl = document.getElementById('total-count');
const bookedCountEl = document.getElementById('booked-count');
const slotsContainer = document.getElementById('slots-container');

let selectedDay = new Date();
let slots = [];
init();
function init() {
  updateSelectedDay(selectedDay);
  setupEventListeners();
}

function setupEventListeners() {
  prevDayBtn.addEventListener('click', () => {
    const newDate = new Date(selectedDay);
    newDate.setDate(selectedDay.getDate() - 1);
    updateSelectedDay(newDate);
  });
  
  nextDayBtn.addEventListener('click', () => {
    const newDate = new Date(selectedDay);
    newDate.setDate(selectedDay.getDate() + 1);
    updateSelectedDay(newDate);
  });
  
  todayBtn.addEventListener('click', () => {
    updateSelectedDay(new Date());
  });
}

function updateSelectedDay(date) {
  selectedDay = date;
  updateDateDisplay();
  generateSlots();
  renderSlots();
}

function updateDateDisplay() {
  const options = { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  };
  currentDateSpan.textContent = selectedDay.toLocaleDateString('en-US', options);
  const monthDayYear = {
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  };
  dateDisplayEl.textContent = selectedDay.toLocaleDateString('en-US', monthDayYear);
}

function generateSlots() {
  const startHour = 9;
  const endHour = 17;
  const slotDuration = 20;
  
  slots = [];
  const startOfDay = new Date(selectedDay);
  startOfDay.setHours(startHour, 0, 0, 0);
  
  let currentSlotStart = startOfDay;
  
  while (currentSlotStart.getHours() < endHour) {
    const slotEndTime = new Date(currentSlotStart);
    slotEndTime.setMinutes(slotEndTime.getMinutes() + slotDuration);
    const startTimeFormatted = formatTime(currentSlotStart);
    const endTimeFormatted = formatTime(slotEndTime);
    const slotId = currentSlotStart.toISOString();
    const isAvailable = Math.random() > 0.3;
    
    slots.push({
      id: slotId,
      startTime: formatTimeForComparison(currentSlotStart),
      endTime: formatTimeForComparison(slotEndTime),
      status: isAvailable ? "available" : "unavailable",
      formattedTime: `${startTimeFormatted} - ${endTimeFormatted}`
    });
    currentSlotStart = slotEndTime;
  }
  
  updateSlotCounters();
}

function formatTime(date) {
  const hours = date.getHours();
  const minutes = date.getMinutes();
  const ampm = hours >= 12 ? 'pm' : 'am';
  const hour = hours % 12 || 12; // Convert 0 to 12 for 12 AM
  
  return `${hour}:${minutes.toString().padStart(2, '0')} ${ampm}`;
}

function formatTimeForComparison(date) {
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  
  return `${hours}:${minutes}`;
}

function updateSlotCounters() {
  const availableCount = slots.filter(slot => slot.status === "available").length;
  const totalCount = slots.length;
  const bookedCount = slots.filter(slot => slot.status === "unavailable").length;
  
  availableCountEl.textContent = availableCount;
  totalCountEl.textContent = totalCount;
  bookedCountEl.textContent = bookedCount;
}

function renderSlots() {
  slotsContainer.innerHTML = '';
  
  if (slots.length === 0) {
    const noSlotsEl = document.createElement('div');
    noSlotsEl.className = 'no-slots';
    noSlotsEl.textContent = 'No slots available for the selected day.';
    slotsContainer.appendChild(noSlotsEl);
    return;
  }
  
  slots.forEach(slot => {
    const slotEl = document.createElement('div');
    slotEl.className = `slot ${slot.status}`;
    
    const isAvailable = slot.status === 'available';
    
    const slotContent = `
      <div class="slot-header">
        <div class="slot-time">
          <span class="slot-time-icon">⏱</span>
          <span class="slot-time-text">${slot.formattedTime}</span>
        </div>
        <span class="slot-status-icon">${isAvailable ? '✓' : '✗'}</span>
      </div>
    `;
    
    slotEl.innerHTML = slotContent;
    if (isAvailable) {
      slotEl.addEventListener('click', () => {
        alert(`Booking slot: ${slot.formattedTime}`);
      });
    }
    
    slotsContainer.appendChild(slotEl);
  });
}

